import React from 'react';
import { Page } from './Page';

export const AskPage = () => <Page title="Ask a question">{null}</Page>;
export default AskPage;
